﻿using Salon.BD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Salon.Pages
{
    /// <summary>
    /// Логика взаимодействия для clientsEdit.xaml
    /// </summary>
    public partial class clientsEdit : Page
    {
        Client client;
        private int curSelPr;
        private int curTypAg = 0;
        private bool isEdit = true;
        public string fnd;
        public clientsEdit(Client client)
        {
            InitializeComponent();
        }
    }
}
